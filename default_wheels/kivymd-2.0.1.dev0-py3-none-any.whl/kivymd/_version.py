release = False
__version__ = "2.0.1.dev0"
__hash__ = "d2f77408999d0298cfbdf75c89d66649880d7492"
__short_hash__ = "d2f7740"
__date__ = "2025-08-30"
