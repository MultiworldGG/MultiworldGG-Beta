from .stiffscroll import StiffScrollEffect
