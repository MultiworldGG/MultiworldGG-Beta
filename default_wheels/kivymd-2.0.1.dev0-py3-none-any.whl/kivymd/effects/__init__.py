"""
Effects
=======
"""
